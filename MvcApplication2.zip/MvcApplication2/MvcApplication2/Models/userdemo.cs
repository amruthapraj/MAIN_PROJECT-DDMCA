﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MvcApplication2.Models
{
    public class userdemo
    {
        public int userdemoId { get; set;}
        [Required]
        [Display(Name="Name")]
        public string name { get; set; }
        [Required]
        [Display(Name = "Username")]
        public string uname { get; set; }
        [Required]
        [Display(Name = "password")]
        [DataType(DataType.Password)]
        public string pwd { get; set; }




        
    }
}
﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication2.Models;

namespace MvcApplication2.Controllers
{
    public class DemoController : Controller
    {
        private UserContext db = new UserContext();

        //
        // GET: /Demo/

        public ActionResult Index()
        {
            return View(db.User.ToList());
        }

        //
        // GET: /Demo/Details/5

        public ActionResult Details(int id = 0)
        {
            userdemo userdemo = db.User.Find(id);
            if (userdemo == null)
            {
                return HttpNotFound();
            }
            return View(userdemo);
        }

        //
        // GET: /Demo/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Demo/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(userdemo userdemo)
        {
            if (ModelState.IsValid)
            {
                db.User.Add(userdemo);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(userdemo);
        }

        //
        // GET: /Demo/Edit/5

        public ActionResult Edit(int id = 0)
        {
            userdemo userdemo = db.User.Find(id);
            if (userdemo == null)
            {
                return HttpNotFound();
            }
            return View(userdemo);
        }

        //
        // POST: /Demo/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(userdemo userdemo)
        {
            if (ModelState.IsValid)
            {
                db.Entry(userdemo).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(userdemo);
        }

        //
        // GET: /Demo/Delete/5

        public ActionResult Delete(int id = 0)
        {
            userdemo userdemo = db.User.Find(id);
            if (userdemo == null)
            {
                return HttpNotFound();
            }
            return View(userdemo);
        }

        //
        // POST: /Demo/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            userdemo userdemo = db.User.Find(id);
            db.User.Remove(userdemo);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}